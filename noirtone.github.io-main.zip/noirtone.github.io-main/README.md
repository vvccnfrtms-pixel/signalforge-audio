# NoirTone Guitars

Boutique electric guitars crafted for premium feel and tone.

This repository contains the website for **NoirTone Guitars**, a business that upgrades affordable donor guitars into high-end boutique instruments.  

**Live website:**

## Website Structure

- `index.html` — Home page with hero image, branding, and CTA buttons  
- `about.html` — About the business and mission  
- `gallery.html` — Showcase of boutique guitars  
- `contact.html` — Contact form for inquiries  
- `style.css` — Main stylesheet for all pages  
- `images/` — All guitar and hero images used on the site  

## Updating the Website

1. Edit the HTML or CSS files in this repository.  
2. Commit your changes.  
3. GitHub Pages automatically updates the live website.

---

**NoirTone Guitars — Boutique Guitars, Premium Feel**
